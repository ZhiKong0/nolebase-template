#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "Motor.h"
#include "Encoder.h"
#include "MPU6050.h"
#include "PID.h"

int main()
{
    OLED_Init();           // 初始化 OLED
	OLED_ShowString(1, 1, "Hello");
	Motor_Init();
	Motor_Enable();
	Encoder_Init();
	MPU6050_Init();
	MPU6050_CalibrateGyroZ(200, 5);

	PID_t SpeedPidL;
	PID_t SpeedPidR;
	PID_t YawPid;
	PID_Init(&SpeedPidL, 0.60f, 0.01f, 0.00f, 0.0f, 99.0f);
	PID_Init(&SpeedPidR, 0.60f, 0.01f, 0.00f, 0.0f, 99.0f);
	PID_Init(&YawPid, 2.00f, 0.00f, 0.00f, -20.0f, 20.0f);

	MotorA_SetDir(MOTOR_DIR_FORWARD);
	MotorB_SetDir(MOTOR_DIR_FORWARD);

	uint16_t baseSetpoint = 200;
	uint8_t pwmL = 0;
	uint8_t pwmR = 0;
	float yaw = 0.0f;

 	OLED_ShowString(2, 1, "MPU:");
 	OLED_ShowHexNum(2, 5, MPU6050_WhoAmI(), 2);
    
    while(1)
    {
		int16_t dL = EncoderA_GetDelta();
		int16_t dR = EncoderB_GetDelta();
		float gz = MPU6050_ReadGyroZ_dps_Calibrated();
		yaw += gz * 0.01f;

		float outL = PID_Update(&SpeedPidL, (float)baseSetpoint, (float)dL);
		float outR = PID_Update(&SpeedPidR, (float)baseSetpoint, (float)dR);
		float corr = PID_Update(&YawPid, 0.0f, yaw);

		float cmdL = outL + corr;
		float cmdR = outR - corr;
		if (cmdL < 0.0f)
			cmdL = 0.0f;
		if (cmdL > 99.0f)
			cmdL = 99.0f;
		if (cmdR < 0.0f)
			cmdR = 0.0f;
		if (cmdR > 99.0f)
			cmdR = 99.0f;

		pwmL = (uint8_t)cmdL;
		pwmR = (uint8_t)cmdR;
		MotorA_SetSpeed(pwmL);
		MotorB_SetSpeed(pwmR);

		OLED_ShowSignedNum(3, 1, dL, 5);
		OLED_ShowSignedNum(4, 1, dR, 5);
		OLED_ShowNum(3, 8, pwmL, 3);
		OLED_ShowNum(4, 8, pwmR, 3);
		OLED_ShowSignedNum(1, 8, (int32_t)yaw, 5);
		OLED_ShowSignedNum(2, 8, (int32_t)gz, 5);

		Delay_ms(10);
	}
}