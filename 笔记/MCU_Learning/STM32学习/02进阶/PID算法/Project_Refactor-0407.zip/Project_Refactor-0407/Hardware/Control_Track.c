#include "Control_Track.h"
#include "Encoder_Timer.h"
#include "ICM42688.h"
#include "Motor.h"
#include "VOFA.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define TRACK_SENSOR_ACTIVE_LOW       1u
#define TRACK_CONTROL_PERIOD_MS       10u
#define TRACK_VOFA_SEND_PERIOD_MS     20u
#define TRACK_BASE_PWM_MIN            0
#define TRACK_PWM_MAX                 72
#define TRACK_TARGET_SPEED_DEFAULT    18.0f
#define TRACK_SPEED_TARGET_SCALE      0.10f
#define TRACK_SPEED_TARGET_RAMP_STEP  0.15f
#define TRACK_SPEED_KP                10.0f
#define TRACK_SPEED_KI                0.25f
#define TRACK_SPEED_KD                0.0f
#define TRACK_SPEED_FF_GAIN           4.0f
#define TRACK_SPEED_INTEGRAL_DECAY    0.75f
#define TRACK_SPEED_FEEDBACK_ALPHA    0.35f
#define TRACK_SPEED_FEEDBACK_WINDOW_TICKS 4u
#define TRACK_SPEED_FEEDBACK_MIN_PULSES 2.0f
#define TRACK_SPEED_START_PWM_MIN     26.0f
#define TRACK_SPEED_START_ACTUAL_MAX  0.50f
#define TRACK_SPEED_START_TARGET_MIN  0.60f
#define TRACK_SPEED_START_KICK_MS     800u
#define TRACK_SPEED_I_LIMIT           240.0f
#define TRACK_SPEED_OUT_LIMIT         100.0f
#define TRACK_SPEED_OUT_SLEW_STEP     6.0f
#define TRACK_COUNT_DIFF_KP           0.00160f
#define TRACK_COUNT_DIFF_KI           0.0f
#define TRACK_COUNT_DIFF_KD           0.00f
#define TRACK_COUNT_DIFF_I_LIMIT      800.0f
#define TRACK_COUNT_DIFF_OUT_LIMIT    3.0f
#define TRACK_GUIDANCE_DISABLED       0u
#define TRACK_LINE_KP                 0.4f
#define TRACK_LINE_KI                 0.004f
#define TRACK_LINE_KD                 0.0f
#define TRACK_LINE_I_LIMIT            120.0f
#define TRACK_LINE_DIFF_TARGET_LIMIT  3.5f
#define TRACK_LINE_DIFF_RATIO_LIMIT   0.30f
#define TRACK_LINE_DIFF_STEP          0.20f
#define TRACK_WHEEL_TARGET_MIN_RATIO  0.75f
#define TRACK_WHEEL_TARGET_MIN_FLOOR  0.45f
#define TRACK_TURN_BASE_REDUCTION_MAX 0.55f
#define TRACK_LINE_RECOVERY_BASE_SCALE 0.50f
#define TRACK_LINE_RECOVERY_DIFF_BOOST 1.35f
#define TRACK_LINE_RECOVERY_MIN_ERROR  0.80f
#define TRACK_GUIDE_CENTER_GAIN       0.25f
#define TRACK_GUIDE_TURN_ENTER_ERROR  1.00f
#define TRACK_GUIDE_TURN_FULL_ERROR   2.50f
#define TRACK_STARTUP_STRAIGHT_MS     600u
#define TRACK_TAKEOVER_RAMP_MS         1000u
#define TRACK_LINE_DEADBAND           0.20f
#define TRACK_LINE_MISS_CONFIRM_COUNT 18u
#define TRACK_POSITION_FILTER_ALPHA   0.45f
#define TRACK_CMD_MAX_PER_CALL        16u
#define TRACK_STARTUP_SOFT_MS         600u

#define MAIN_MODE_STRAIGHT            0u
#define MAIN_MODE_TRACK               1u

extern volatile uint8_t g_mainSelectedMode;

static uint8_t track_startup_straight_active(ControlTrackSystem_t *sys);

#define TRACK_S1_PORT                 GPIOA
#define TRACK_S1_PIN                  GPIO_Pin_10
#define TRACK_S2_PORT                 GPIOA
#define TRACK_S2_PIN                  GPIO_Pin_11
#define TRACK_S3_PORT                 GPIOA
#define TRACK_S3_PIN                  GPIO_Pin_12
#define TRACK_S4_PORT                 GPIOB
#define TRACK_S4_PIN                  GPIO_Pin_3
#define TRACK_S5_PORT                 GPIOB
#define TRACK_S5_PIN                  GPIO_Pin_4
#define TRACK_S6_PORT                 GPIOB
#define TRACK_S6_PIN                  GPIO_Pin_9
#define TRACK_S7_PORT                 GPIOB
#define TRACK_S7_PIN                  GPIO_Pin_11
#define TRACK_S8_PORT                 GPIOC
#define TRACK_S8_PIN                  GPIO_Pin_13

static const int16_t g_trackSensorWeights[8] = { -350, -250, -150, -50, 50, 150, 250, 350 };

static float track_absf(float v)
{
    return (v >= 0.0f) ? v : -v;
}

static float track_shape_line_position(float rawPosition, uint8_t sensorCount)
{
    float errorAbs;

    errorAbs = track_absf(rawPosition);
    if (sensorCount == 1u && errorAbs <= 0.5f) {
        return rawPosition * 0.45f;
    }
    if (sensorCount == 1u && errorAbs <= 1.5f) {
        return rawPosition * 0.60f;
    }
    if (errorAbs <= 0.5f) {
        return rawPosition * 0.35f;
    }
    if (errorAbs <= 1.5f) {
        return rawPosition * 0.65f;
    }
    return rawPosition;
}

static float track_clampf(float v, float minV, float maxV)
{
    if (v < minV) return minV;
    if (v > maxV) return maxV;
    return v;
}

static float track_turn_normalized(float errorAbs)
{
    return track_clampf((errorAbs - TRACK_GUIDE_TURN_ENTER_ERROR) /
        (TRACK_GUIDE_TURN_FULL_ERROR - TRACK_GUIDE_TURN_ENTER_ERROR), 0.0f, 1.0f);
}

static float track_guidance_gain(float errorAbs, uint8_t sensorCount)
{
    float turnNormalized;

    if (sensorCount == 0u) {
        return 1.0f;
    }

    if (errorAbs <= TRACK_LINE_DEADBAND) {
        return 0.0f;
    }

    turnNormalized = track_turn_normalized(errorAbs);
    return TRACK_GUIDE_CENTER_GAIN + (1.0f - TRACK_GUIDE_CENTER_GAIN) * turnNormalized;
}

static int16_t track_clamp_i16(int16_t v, int16_t minV, int16_t maxV)
{
    if (v < minV) return minV;
    if (v > maxV) return maxV;
    return v;
}

static float track_parse_float_after_eq(const char *s)
{
    const char *p = strchr(s, '=');
    if (!p) return 0.0f;
    return (float)atof(p + 1);
}

static int16_t track_parse_int_after_eq(const char *s)
{
    return (int16_t)track_parse_float_after_eq(s);
}

static void track_send_text(const char *text)
{
    if (!text) return;
    VOFA_SendString(text);
}

static void track_send_ok(const char *tag)
{
    char out[32];
    snprintf(out, sizeof(out), "OK %s\r\n", tag);
    track_send_text(out);
}

static void track_send_err(void)
{
    track_send_text("ERR\r\n");
}

static void track_sensor_gpio_init(void)
{
    GPIO_InitTypeDef g;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC, ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    g.GPIO_Mode = GPIO_Mode_IPU;
    g.GPIO_Speed = GPIO_Speed_50MHz;

    g.GPIO_Pin = TRACK_S1_PIN | TRACK_S2_PIN | TRACK_S3_PIN;
    GPIO_Init(GPIOA, &g);

    g.GPIO_Pin = TRACK_S4_PIN | TRACK_S5_PIN | TRACK_S6_PIN | TRACK_S7_PIN;
    GPIO_Init(GPIOB, &g);

    g.GPIO_Pin = TRACK_S8_PIN;
    GPIO_Init(GPIOC, &g);
}

static uint8_t track_sensor_is_active(GPIO_TypeDef *port, uint16_t pin)
{
    uint8_t level = (GPIO_ReadInputDataBit(port, pin) == Bit_SET) ? 1u : 0u;
#if TRACK_SENSOR_ACTIVE_LOW
    return level ? 0u : 1u;
#else
    return level;
#endif
}

static uint8_t track_read_sensor_bits(void)
{
    uint8_t bits = 0u;

    if (track_sensor_is_active(TRACK_S1_PORT, TRACK_S1_PIN)) bits |= (uint8_t)(1u << 0);
    if (track_sensor_is_active(TRACK_S2_PORT, TRACK_S2_PIN)) bits |= (uint8_t)(1u << 1);
    if (track_sensor_is_active(TRACK_S3_PORT, TRACK_S3_PIN)) bits |= (uint8_t)(1u << 2);
    if (track_sensor_is_active(TRACK_S4_PORT, TRACK_S4_PIN)) bits |= (uint8_t)(1u << 3);
    if (track_sensor_is_active(TRACK_S5_PORT, TRACK_S5_PIN)) bits |= (uint8_t)(1u << 4);
    if (track_sensor_is_active(TRACK_S6_PORT, TRACK_S6_PIN)) bits |= (uint8_t)(1u << 5);
    if (track_sensor_is_active(TRACK_S7_PORT, TRACK_S7_PIN)) bits |= (uint8_t)(1u << 6);
    if (track_sensor_is_active(TRACK_S8_PORT, TRACK_S8_PIN)) bits |= (uint8_t)(1u << 7);

    return bits;
}

static uint8_t track_bit_count(uint8_t bits)
{
    uint8_t n = 0u;
    while (bits) {
        if (bits & 0x01u) n++;
        bits >>= 1;
    }
    return n;
}

static uint8_t track_sample_line(ControlTrackSystem_t *sys)
{
    uint8_t bits;
    uint8_t count;
    uint8_t i;
    int32_t sum = 0;
    uint8_t hadLine;
    float rawPosition;
    float shapedPosition;

    bits = track_read_sensor_bits();
    count = track_bit_count(bits);

    sys->sensorBits = bits;
    sys->sensorCount = count;

    if (count == 0u) {
        sys->lineDetected = 0u;
        return 0u;
    }

    for (i = 0u; i < 8u; i++) {
        if ((bits & (uint8_t)(1u << i)) != 0u) {
            sum += g_trackSensorWeights[i];
        }
    }

    hadLine = sys->lineDetected;
    rawPosition = (float)sum / (float)count / 100.0f;
    shapedPosition = track_shape_line_position(rawPosition, count);
    sys->lineDetected = 1u;
    sys->linePositionRaw = rawPosition;
    if (!hadLine || (sys->lineMissingCount > 0u)) {
        sys->linePosition = shapedPosition;
    } else {
        sys->linePosition += (shapedPosition - sys->linePosition) * TRACK_POSITION_FILTER_ALPHA;
    }
    return 1u;
}

static void track_reset_speed_loop(ControlTrackSystem_t *sys)
{
    sys->speedTargetCurrent = 0.0f;
    sys->leftTargetSpeed = 0.0f;
    sys->rightTargetSpeed = 0.0f;
    sys->leftActualSpeed = 0.0f;
    sys->rightActualSpeed = 0.0f;
    sys->leftFeedbackAccum = 0;
    sys->rightFeedbackAccum = 0;
    sys->speedFeedbackTicks = 0u;
    sys->leftFeedbackSpeed = 0.0f;
    sys->rightFeedbackSpeed = 0.0f;
    sys->leftSpeedError = 0.0f;
    sys->rightSpeedError = 0.0f;
    sys->leftSpeedIntegral = 0.0f;
    sys->rightSpeedIntegral = 0.0f;
    sys->leftSpeedPrevError = 0.0f;
    sys->rightSpeedPrevError = 0.0f;
    sys->leftSpeedOut = 0.0f;
    sys->rightSpeedOut = 0.0f;
    sys->countDiffError = 0.0f;
    sys->countDiffIntegral = 0.0f;
    sys->countDiffPrevError = 0.0f;
    sys->countDiffOut = 0.0f;
}

static uint8_t track_update_feedback_speed(ControlTrackSystem_t *sys)
{
    float tickScale;
    float leftAccumAbs;
    float rightAccumAbs;

    if (!sys) {
        return 0u;
    }

    sys->leftFeedbackAccum += sys->encoder.leftSpeed;
    sys->rightFeedbackAccum += sys->encoder.rightSpeed;

    if (sys->speedFeedbackTicks < 255u) {
        sys->speedFeedbackTicks++;
    }

    if (sys->speedFeedbackTicks < TRACK_SPEED_FEEDBACK_WINDOW_TICKS) {
        return 0u;
    }

    if (track_startup_straight_active(sys)) {
        leftAccumAbs = track_absf((float)sys->leftFeedbackAccum);
        rightAccumAbs = track_absf((float)sys->rightFeedbackAccum);
        if (leftAccumAbs < TRACK_SPEED_FEEDBACK_MIN_PULSES ||
            rightAccumAbs < TRACK_SPEED_FEEDBACK_MIN_PULSES) {
            return 0u;
        }
    }

    tickScale = (float)sys->speedFeedbackTicks;
    if (tickScale < 1.0f) {
        tickScale = 1.0f;
    }

    sys->leftFeedbackSpeed = (float)sys->leftFeedbackAccum / tickScale;
    sys->rightFeedbackSpeed = (float)sys->rightFeedbackAccum / tickScale;
    sys->leftFeedbackAccum = 0;
    sys->rightFeedbackAccum = 0;
    sys->speedFeedbackTicks = 0u;
    return 1u;
}

static void track_reset_line_loop(ControlTrackSystem_t *sys)
{
    sys->lineError = 0.0f;
    sys->lineIntegral = 0.0f;
    sys->linePrevError = 0.0f;
    sys->linePidOut = 0.0f;
    sys->lineDiffTarget = 0.0f;
    sys->lastSeenError = 0.0f;
}

static float track_ramp_speed_target(ControlTrackSystem_t *sys)
{
    float target = track_clampf(sys->targetSpeed, 0.0f, 100.0f) * TRACK_SPEED_TARGET_SCALE;

    if (sys->speedTargetCurrent < target) {
        sys->speedTargetCurrent += TRACK_SPEED_TARGET_RAMP_STEP;
        if (sys->speedTargetCurrent > target) sys->speedTargetCurrent = target;
    } else if (sys->speedTargetCurrent > target) {
        sys->speedTargetCurrent -= TRACK_SPEED_TARGET_RAMP_STEP;
        if (sys->speedTargetCurrent < target) sys->speedTargetCurrent = target;
    }
    return sys->speedTargetCurrent;
}

static float track_startup_release(ControlTrackSystem_t *sys)
{
    uint32_t elapsed;

    if (!sys || !sys->isRunning) {
        return 1.0f;
    }

    elapsed = sys->tickCount - sys->runStartTick;
    if (elapsed >= TRACK_STARTUP_SOFT_MS) {
        return 1.0f;
    }

    return 0.35f + 0.65f * ((float)elapsed / (float)TRACK_STARTUP_SOFT_MS);
}

static uint8_t track_startup_straight_active(ControlTrackSystem_t *sys)
{
    uint32_t elapsed;

    if (!sys || !sys->isRunning) {
        return 0u;
    }

    elapsed = sys->tickCount - sys->runStartTick;
    return (elapsed < TRACK_STARTUP_STRAIGHT_MS) ? 1u : 0u;
}

static float track_takeover_release(ControlTrackSystem_t *sys)
{
    uint32_t elapsed;
    uint32_t handoffElapsed;

    if (!sys || !sys->isRunning) {
        return 1.0f;
    }

    elapsed = sys->tickCount - sys->runStartTick;
    if (elapsed <= TRACK_STARTUP_STRAIGHT_MS) {
        return 0.0f;
    }

    handoffElapsed = elapsed - TRACK_STARTUP_STRAIGHT_MS;
    if (handoffElapsed >= TRACK_TAKEOVER_RAMP_MS) {
        return 1.0f;
    }

    return (float)handoffElapsed / (float)TRACK_TAKEOVER_RAMP_MS;
}

static float track_adjust_base_target(ControlTrackSystem_t *sys, float baseTarget)
{
    float errorAbs;
    float normalized;
    float scale;
    float release;
    float takeover;

    release = track_startup_release(sys);
#if TRACK_GUIDANCE_DISABLED
    return track_clampf(baseTarget * release, 0.30f, baseTarget);
#endif

    errorAbs = track_absf(sys->linePosition);
    normalized = track_turn_normalized(errorAbs);
    takeover = track_takeover_release(sys);
    scale = 1.0f - normalized * TRACK_TURN_BASE_REDUCTION_MAX * takeover;

    if (track_startup_straight_active(sys)) {
        return track_clampf(baseTarget * release, 0.30f, baseTarget);
    }

    if (sys->sensorCount <= 1u && errorAbs >= 1.5f) {
        scale *= 1.0f - 0.35f * takeover;
    }

    if (sys->sensorCount <= 1u && errorAbs >= 2.5f) {
        scale *= 1.0f - 0.20f * takeover;
    }

    if (sys->sensorCount == 0u && sys->lineMissingCount > 0u) {
        scale *= 1.0f - (1.0f - TRACK_LINE_RECOVERY_BASE_SCALE) * takeover;
    }

    scale *= release;

    return track_clampf(baseTarget * scale, 0.30f, baseTarget);
}

static void track_mix_target_speeds(ControlTrackSystem_t *sys, float baseTarget)
{
    float diffLimit;
    float diffTarget;
    float diffStep;
    float guidanceGain;
    float minWheelTarget;
    float minWheelRatio;
    float leftTarget;
    float rightTarget;
    float errorAbs;
    float normalized;
    float release;
    float takeover;

#if TRACK_GUIDANCE_DISABLED
    sys->lineDiffTarget = 0.0f;
    sys->leftTargetSpeed = track_clampf(baseTarget, 0.0f, 20.0f);
    sys->rightTargetSpeed = track_clampf(baseTarget, 0.0f, 20.0f);
    return;
#endif

    if (track_startup_straight_active(sys)) {
        sys->lineDiffTarget = 0.0f;
        sys->leftTargetSpeed = track_clampf(baseTarget, 0.0f, 20.0f);
        sys->rightTargetSpeed = track_clampf(baseTarget, 0.0f, 20.0f);
        return;
    }

    errorAbs = track_absf(sys->linePosition);
    normalized = track_turn_normalized(errorAbs);
    guidanceGain = track_guidance_gain(errorAbs, sys->sensorCount);
    takeover = track_takeover_release(sys);
    diffLimit = track_clampf(baseTarget * TRACK_LINE_DIFF_RATIO_LIMIT + 0.05f, 0.18f, TRACK_LINE_DIFF_TARGET_LIMIT);
    release = track_startup_release(sys);
    diffLimit *= (0.30f + 0.70f * takeover) * (0.65f + 0.35f * release);
    if (sys->sensorCount == 0u && sys->lineMissingCount > 0u) {
        diffLimit *= TRACK_LINE_RECOVERY_DIFF_BOOST;
    }
    diffTarget = track_clampf(sys->linePidOut * guidanceGain * takeover, -diffLimit, diffLimit);
    diffStep = TRACK_LINE_DIFF_STEP * (0.25f + 0.75f * takeover) * (0.55f + 0.45f * release) * (0.35f + 0.65f * normalized);

    if (sys->lineDiffTarget < diffTarget) {
        sys->lineDiffTarget += diffStep;
        if (sys->lineDiffTarget > diffTarget) {
            sys->lineDiffTarget = diffTarget;
        }
    } else if (sys->lineDiffTarget > diffTarget) {
        sys->lineDiffTarget -= diffStep;
        if (sys->lineDiffTarget < diffTarget) {
            sys->lineDiffTarget = diffTarget;
        }
    }

    minWheelRatio = TRACK_WHEEL_TARGET_MIN_RATIO - 0.20f * normalized - 0.10f * (1.0f - release);
    if (sys->sensorCount == 0u && sys->lineMissingCount > 0u) {
        minWheelRatio -= 0.10f;
    }
    minWheelRatio = track_clampf(minWheelRatio, TRACK_WHEEL_TARGET_MIN_FLOOR, TRACK_WHEEL_TARGET_MIN_RATIO);
    minWheelTarget = baseTarget * minWheelRatio;

    leftTarget = baseTarget + sys->lineDiffTarget;
    rightTarget = baseTarget - sys->lineDiffTarget;

    if (baseTarget > 0.0f) {
        leftTarget = track_clampf(leftTarget, minWheelTarget, baseTarget + diffLimit);
        rightTarget = track_clampf(rightTarget, minWheelTarget, baseTarget + diffLimit);
    }

    sys->leftTargetSpeed = track_clampf(leftTarget, 0.0f, 20.0f);
    sys->rightTargetSpeed = track_clampf(rightTarget, 0.0f, 20.0f);
}

static void track_apply_output(ControlTrackSystem_t *sys, int16_t leftPwm, int16_t rightPwm)
{
    sys->leftPwm = leftPwm;
    sys->rightPwm = rightPwm;
    Motor_SetDiffSpeed(leftPwm, rightPwm);
}

static void track_stop_output(ControlTrackSystem_t *sys)
{
    sys->leftPwm = 0;
    sys->rightPwm = 0;
    sys->basePwm = 0;
    sys->linePidOut = 0.0f;
    sys->lineDiffTarget = 0.0f;
    sys->leftSpeedOut = 0.0f;
    sys->rightSpeedOut = 0.0f;
    Motor_Stop();
    Motor_Disable();
}

static void track_poll_imu(ControlTrackSystem_t *sys)
{
    float dt = 0.005f;
    uint32_t pollTick;
    uint32_t prevYawSampleTick;
    ICM42688_Data_t icmNext;

    memcpy(&icmNext, &sys->icm, sizeof(icmNext));
    prevYawSampleTick = sys->imuYawSampleTick;

    if (!ICM42688_ReadAll(&icmNext)) {
        return;
    }

    pollTick = sys->tickCount;
    if (icmNext.yawSampleUpdated) {
        if (prevYawSampleTick != 0u && pollTick >= prevYawSampleTick) {
            dt = (float)(pollTick - prevYawSampleTick) * 0.001f;
            if (dt <= 0.0f) {
                dt = 0.005f;
            }
        }
        ICM42688_UpdateYaw(&icmNext, dt);
        sys->imuYawSampleTick = pollTick;
    }

    memcpy(&sys->icm, &icmNext, sizeof(sys->icm));
    sys->imuDataValid = 1u;
}

static void track_send_hb(ControlTrackSystem_t *sys)
{
    static char out[640];
    uint32_t tMs = 0u;

    if (sys->isRunning || sys->expActive) {
        tMs = sys->tickCount - sys->runStartTick;
    }

    snprintf(out, sizeof(out),
             "TRK tick=%lu exp_id=%u t_ms=%lu run=%u ts=%.3f kp=%.3f ki=%.3f kd=%.3f st=%.3f lt=%.3f rt=%.3f la=%.3f ra=%.3f lse=%.3f rse=%.3f lso=%.3f rso=%.3f lc=%ld rc=%ld cd=%ld cde=%.3f cdo=%.3f lp=%.3f lpr=%.3f y=%.3f yr=%.3f el=%.3f er=%.3f ed=%.3f dl=%d dr=%d cl=%u cr=%u L=%d R=%d s1=%u s2=%u s3=%u s4=%u s5=%u s6=%u s7=%u s8=%u rx=%lu txdrop=%lu\r\n",
             (unsigned long)sys->tickCount,
             (unsigned)sys->expId,
             (unsigned long)tMs,
             (unsigned)sys->isRunning,
             (double)sys->targetSpeed,
             (double)sys->lineKp,
             (double)sys->lineKi,
             (double)sys->lineKd,
             (double)sys->speedTargetCurrent,
             (double)sys->leftTargetSpeed,
             (double)sys->rightTargetSpeed,
             (double)sys->leftActualSpeed,
             (double)sys->rightActualSpeed,
             (double)sys->leftSpeedError,
             (double)sys->rightSpeedError,
             (double)sys->leftSpeedOut,
             (double)sys->rightSpeedOut,
             (long)sys->encoder.leftCount,
             (long)sys->encoder.rightCount,
             (long)(sys->encoder.leftCount - sys->encoder.rightCount),
             (double)sys->countDiffError,
             (double)sys->countDiffOut,
             (double)sys->linePosition,
             (double)sys->linePositionRaw,
             (double)sys->icm.yaw,
             (double)sys->icm.yawRate,
             (double)sys->leftFeedbackSpeed,
             (double)sys->rightFeedbackSpeed,
             (double)(sys->leftFeedbackSpeed - sys->rightFeedbackSpeed),
             (int)sys->encoder.rawLeftDelta,
             (int)sys->encoder.rawRightDelta,
             (unsigned)sys->encoder.leftDeltaClamped,
             (unsigned)sys->encoder.rightDeltaClamped,
             (int)sys->leftPwm,
             (int)sys->rightPwm,
             (unsigned)((sys->sensorBits >> 0) & 0x01u),
             (unsigned)((sys->sensorBits >> 1) & 0x01u),
             (unsigned)((sys->sensorBits >> 2) & 0x01u),
             (unsigned)((sys->sensorBits >> 3) & 0x01u),
             (unsigned)((sys->sensorBits >> 4) & 0x01u),
             (unsigned)((sys->sensorBits >> 5) & 0x01u),
             (unsigned)((sys->sensorBits >> 6) & 0x01u),
             (unsigned)((sys->sensorBits >> 7) & 0x01u),
             (unsigned long)VOFA_GetRxByteCount(),
             (unsigned long)VOFA_GetTxDropByteCount());
    track_send_text(out);
}

static void track_send_stat(ControlTrackSystem_t *sys)
{
    static char out[832];
    uint32_t tMs = 0u;

    if (sys->isRunning || sys->expActive) {
        tMs = sys->tickCount - sys->runStartTick;
    }

    snprintf(out, sizeof(out),
             "STAT tick=%lu exp_id=%u t_ms=%lu run=%u ts=%.6f skp=%.6f ski=%.6f skd=%.6f kp=%.6f ki=%.6f kd=%.6f st=%.6f lt=%.6f rt=%.6f la=%.6f ra=%.6f lse=%.6f rse=%.6f lso=%.6f rso=%.6f lc=%ld rc=%ld cd=%ld cde=%.6f cdi=%.6f cdo=%.6f lp=%.6f lpr=%.6f le=%.6f li=%.6f lout=%.6f diff=%.6f y=%.6f yr=%.6f el=%.3f er=%.3f ed=%.3f dl=%d dr=%d cl=%u cr=%u L=%d R=%d pwm_max=%u miss=%u lost=%u s1=%u s2=%u s3=%u s4=%u s5=%u s6=%u s7=%u s8=%u rx=%lu txdrop=%lu\r\n",
             (unsigned long)sys->tickCount,
             (unsigned)sys->expId,
             (unsigned long)tMs,
             (unsigned)sys->isRunning,
             (double)sys->targetSpeed,
             (double)sys->speedKp,
             (double)sys->speedKi,
             (double)sys->speedKd,
             (double)sys->lineKp,
             (double)sys->lineKi,
             (double)sys->lineKd,
             (double)sys->speedTargetCurrent,
             (double)sys->leftTargetSpeed,
             (double)sys->rightTargetSpeed,
             (double)sys->leftActualSpeed,
             (double)sys->rightActualSpeed,
             (double)sys->leftSpeedError,
             (double)sys->rightSpeedError,
             (double)sys->leftSpeedOut,
             (double)sys->rightSpeedOut,
             (long)sys->encoder.leftCount,
             (long)sys->encoder.rightCount,
             (long)(sys->encoder.leftCount - sys->encoder.rightCount),
             (double)sys->countDiffError,
             (double)sys->countDiffIntegral,
             (double)sys->countDiffOut,
             (double)sys->linePosition,
             (double)sys->linePositionRaw,
             (double)sys->lineError,
             (double)sys->lineIntegral,
             (double)sys->linePidOut,
             (double)sys->lineDiffTarget,
             (double)sys->icm.yaw,
             (double)sys->icm.yawRate,
             (double)sys->leftFeedbackSpeed,
             (double)sys->rightFeedbackSpeed,
             (double)(sys->leftFeedbackSpeed - sys->rightFeedbackSpeed),
             (int)sys->encoder.rawLeftDelta,
             (int)sys->encoder.rawRightDelta,
             (unsigned)sys->encoder.leftDeltaClamped,
             (unsigned)sys->encoder.rightDeltaClamped,
             (int)sys->leftPwm,
             (int)sys->rightPwm,
             (unsigned)sys->pwmMax,
             (unsigned)sys->lineMissingCount,
             (unsigned)sys->lineLostCount,
             (unsigned)((sys->sensorBits >> 0) & 0x01u),
             (unsigned)((sys->sensorBits >> 1) & 0x01u),
             (unsigned)((sys->sensorBits >> 2) & 0x01u),
             (unsigned)((sys->sensorBits >> 3) & 0x01u),
             (unsigned)((sys->sensorBits >> 4) & 0x01u),
             (unsigned)((sys->sensorBits >> 5) & 0x01u),
             (unsigned)((sys->sensorBits >> 6) & 0x01u),
             (unsigned)((sys->sensorBits >> 7) & 0x01u),
             (unsigned long)VOFA_GetRxByteCount(),
             (unsigned long)VOFA_GetTxDropByteCount());
    track_send_text(out);
}

static void track_stop_experiment(ControlTrackSystem_t *sys)
{
    if (!sys) return;
    sys->expActive = 0u;
    sys->expDurationMs = 0u;
}

static void track_handle_exp_timeout(ControlTrackSystem_t *sys)
{
    char out[40];

    if (!sys->expActive) return;
    if ((sys->tickCount - sys->expStartTick) < sys->expDurationMs) return;

    track_stop_experiment(sys);
    if (sys->isRunning) {
        ControlTrack_Stop(sys);
    }
    snprintf(out, sizeof(out), "EXP_END id=%u\r\n", (unsigned)sys->expId);
    track_send_text(out);
}

static void track_parse_cmd(ControlTrackSystem_t *sys, const char *cmd)
{
    unsigned id;
    unsigned ms;

    if (!sys || !cmd) return;

    if (strcmp(cmd, "#RUN") == 0 || strcmp(cmd, "#RUN!") == 0) {
        if (!sys->isRunning) {
            if (!ControlTrack_Start(sys)) {
                track_send_err();
                return;
            }
        }
        track_send_ok("RUN");
        return;
    }
    if (strcmp(cmd, "#STOP") == 0 || strcmp(cmd, "#STOP!") == 0) {
        track_stop_experiment(sys);
        ControlTrack_Stop(sys);
        track_send_ok("STOP");
        return;
    }
    if (strcmp(cmd, "#STAT") == 0 || strcmp(cmd, "#STAT!") == 0) {
        track_send_stat(sys);
        return;
    }
    if (strcmp(cmd, "#CAL") == 0 || strcmp(cmd, "#CAL!") == 0) {
        if (ICM42688_ReadAll(&sys->icm)) {
            ICM42688_ResetAttitude(&sys->icm);
            sys->imuYawSampleTick = sys->tickCount;
            sys->imuDataValid = 1u;
        }
        track_send_ok("CAL");
        return;
    }
    if (strcmp(cmd, "#MODE=TRACK") == 0 || strcmp(cmd, "#MODE=TRACK!") == 0) {
        g_mainSelectedMode = MAIN_MODE_TRACK;
        track_send_ok("MODE");
        return;
    }
    if (strcmp(cmd, "#MODE=STRAIGHT") == 0 || strcmp(cmd, "#MODE=STRAIGHT!") == 0) {
        if (sys->isRunning) {
            track_send_err();
            return;
        }
        g_mainSelectedMode = MAIN_MODE_STRAIGHT;
        track_send_ok("MODE");
        return;
    }
    if (strncmp(cmd, "#EXP=STREAM,", 12) == 0) {
        unsigned en = 0u;
        if (sscanf(cmd, "#EXP=STREAM,%u", &en) == 1) {
            sys->expStreamEnabled = (en != 0u) ? 1u : 0u;
            track_send_ok("EXP_STREAM");
        } else {
            track_send_err();
        }
        return;
    }
    if (sscanf(cmd, "#EXP=RUN,%u,%u", &id, &ms) == 2) {
        sys->expId = (uint16_t)id;
        sys->expStartTick = sys->tickCount;
        sys->expDurationMs = (uint32_t)ms;
        sys->expActive = 1u;
        if (!sys->isRunning) {
            if (!ControlTrack_Start(sys)) {
                track_stop_experiment(sys);
                track_send_err();
                return;
            }
        }
        track_send_ok("EXP_START");
        return;
    }
    if (sscanf(cmd, "#EXP=STOP,%u", &id) == 1) {
        if ((uint16_t)id == sys->expId || sys->expId == 0u) {
            track_stop_experiment(sys);
            ControlTrack_Stop(sys);
            track_send_ok("EXP_STOP");
            return;
        }
        track_send_err();
        return;
    }
    if (strncmp(cmd, "#TS=", 4) == 0) {
        sys->targetSpeed = track_parse_float_after_eq(cmd);
        track_send_ok("TS");
        return;
    }
    if (strncmp(cmd, "#SKP=", 5) == 0) {
        sys->speedKp = track_parse_float_after_eq(cmd);
        track_reset_speed_loop(sys);
        track_send_ok("SKP");
        return;
    }
    if (strncmp(cmd, "#SKI=", 5) == 0) {
        sys->speedKi = track_parse_float_after_eq(cmd);
        track_reset_speed_loop(sys);
        track_send_ok("SKI");
        return;
    }
    if (strncmp(cmd, "#SKD=", 5) == 0) {
        sys->speedKd = track_parse_float_after_eq(cmd);
        track_reset_speed_loop(sys);
        track_send_ok("SKD");
        return;
    }
    if (strncmp(cmd, "#AKP=", 5) == 0 || strncmp(cmd, "#KP=", 4) == 0) {
        sys->lineKp = track_parse_float_after_eq(cmd);
        track_reset_line_loop(sys);
        track_send_ok("AKP");
        return;
    }
    if (strncmp(cmd, "#AKI=", 5) == 0 || strncmp(cmd, "#KI=", 4) == 0) {
        sys->lineKi = track_parse_float_after_eq(cmd);
        track_reset_line_loop(sys);
        track_send_ok("AKI");
        return;
    }
    if (strncmp(cmd, "#AKD=", 5) == 0 || strncmp(cmd, "#KD=", 4) == 0) {
        sys->lineKd = track_parse_float_after_eq(cmd);
        track_reset_line_loop(sys);
        track_send_ok("AKD");
        return;
    }
    if (strncmp(cmd, "#PWM_MAX=", 9) == 0) {
        int16_t v = track_parse_int_after_eq(cmd);
        sys->pwmMax = (uint16_t)track_clamp_i16(v, TRACK_BASE_PWM_MIN, 100);
        track_send_ok("PWM_MAX");
        return;
    }

    track_send_err();
}

static void track_update_line_outer_loop(ControlTrackSystem_t *sys)
{
    float error;
    float derivative;
    float pidOut;
    float takeover;

#if TRACK_GUIDANCE_DISABLED
    if (track_sample_line(sys)) {
        sys->lineMissingCount = 0u;
        sys->lineLostCount = 0u;
        sys->lastSeenError = sys->linePosition;
    } else if (sys->lineMissingCount < 255u) {
        sys->lineMissingCount++;
    }

    sys->lineError = 0.0f;
    sys->lineIntegral *= TRACK_SPEED_INTEGRAL_DECAY;
    sys->linePrevError = 0.0f;
    sys->linePidOut = 0.0f;
    sys->lineDiffTarget = 0.0f;
    return;
#endif

    if (track_startup_straight_active(sys)) {
        if (track_sample_line(sys)) {
            sys->lineMissingCount = 0u;
            sys->lineLostCount = 0u;
            sys->lastSeenError = sys->linePosition;
        } else {
            sys->lineDetected = 0u;
            sys->lineMissingCount = 0u;
            sys->lineLostCount = 0u;
        }

        sys->lineError = 0.0f;
        sys->lineIntegral *= TRACK_SPEED_INTEGRAL_DECAY;
        sys->linePrevError = 0.0f;
        sys->linePidOut = 0.0f;
        sys->lineDiffTarget = 0.0f;
        return;
    }

    if (!track_sample_line(sys)) {
        if (sys->lineMissingCount < 255u) {
            sys->lineMissingCount++;
        }

        if (sys->lineMissingCount >= TRACK_LINE_MISS_CONFIRM_COUNT) {
            sys->lineDetected = 0u;
            sys->lineLostCount++;
            ControlTrack_Stop(sys);
            return;
        }

        error = sys->lastSeenError;
        if (track_absf(error) < TRACK_LINE_RECOVERY_MIN_ERROR) {
            error = (error >= 0.0f) ? TRACK_LINE_RECOVERY_MIN_ERROR : -TRACK_LINE_RECOVERY_MIN_ERROR;
        }
        sys->linePosition = error;
    } else {
        sys->lineMissingCount = 0u;
        sys->lineLostCount = 0u;
        error = sys->linePosition;
        sys->lastSeenError = error;
    }

    sys->lineError = error;
    sys->lineIntegral += error;
    sys->lineIntegral = track_clampf(sys->lineIntegral, -TRACK_LINE_I_LIMIT, TRACK_LINE_I_LIMIT);
    derivative = error - sys->linePrevError;
    pidOut = sys->lineKp * error + sys->lineKi * sys->lineIntegral + sys->lineKd * derivative;

    if (track_absf(error) <= TRACK_LINE_DEADBAND) {
        sys->lineIntegral *= TRACK_SPEED_INTEGRAL_DECAY;
        pidOut = 0.0f;
    } else {
        takeover = track_takeover_release(sys);
        pidOut *= track_guidance_gain(track_absf(error), sys->sensorCount) * takeover;
    }

    sys->linePidOut = track_clampf(pidOut, -TRACK_LINE_DIFF_TARGET_LIMIT, TRACK_LINE_DIFF_TARGET_LIMIT);
    sys->lineDiffTarget = sys->linePidOut;
    sys->linePrevError = error;
}

static float track_speed_pid_step(float target, float actual, float *integral, float *prevError, float kp, float ki, float kd, float ffGain, uint8_t feedbackReady)
{
    float error = target - actual;
    float nextIntegral = *integral;
    float derivative = 0.0f;
    float ff;
    float out;

    if (target <= 0.0f) {
        *integral *= TRACK_SPEED_INTEGRAL_DECAY;
        *prevError = 0.0f;
        return 0.0f;
    }

    if (feedbackReady) {
        nextIntegral = *integral + error;
        nextIntegral = track_clampf(nextIntegral, -TRACK_SPEED_I_LIMIT, TRACK_SPEED_I_LIMIT);
        derivative = error - *prevError;
    }

    ff = target * ffGain;
    out = ff + kp * error + ki * nextIntegral + kd * derivative;

    if (feedbackReady && ((out >= TRACK_SPEED_OUT_LIMIT && error > 0.0f) || (out <= 0.0f && error < 0.0f))) {
        nextIntegral = (*integral) * TRACK_SPEED_INTEGRAL_DECAY;
        out = ff + kp * error + ki * nextIntegral + kd * derivative;
    }

    if (feedbackReady) {
        *integral = nextIntegral;
        *prevError = error;
    }

    return track_clampf(out, 0.0f, TRACK_SPEED_OUT_LIMIT);
}

static float track_apply_output_slew(float targetOut, float currentOut)
{
    if (targetOut > currentOut + TRACK_SPEED_OUT_SLEW_STEP) {
        return currentOut + TRACK_SPEED_OUT_SLEW_STEP;
    }

    if (targetOut < currentOut - TRACK_SPEED_OUT_SLEW_STEP) {
        return currentOut - TRACK_SPEED_OUT_SLEW_STEP;
    }

    return targetOut;
}

static float track_count_diff_pid_step(ControlTrackSystem_t *sys)
{
    float error;
    float nextIntegral;
    float derivative;
    float out;

    if (!sys) {
        return 0.0f;
    }

    error = (float)(sys->encoder.rightCount - sys->encoder.leftCount);
    nextIntegral = sys->countDiffIntegral + error;
    nextIntegral = track_clampf(nextIntegral, -TRACK_COUNT_DIFF_I_LIMIT, TRACK_COUNT_DIFF_I_LIMIT);
    derivative = error - sys->countDiffPrevError;
    out = TRACK_COUNT_DIFF_KP * error + TRACK_COUNT_DIFF_KI * nextIntegral + TRACK_COUNT_DIFF_KD * derivative;
    out = track_clampf(out, -TRACK_COUNT_DIFF_OUT_LIMIT, TRACK_COUNT_DIFF_OUT_LIMIT);

    sys->countDiffError = error;
    sys->countDiffIntegral = nextIntegral;
    sys->countDiffPrevError = error;
    sys->countDiffOut = out;
    return out;
}

static float track_apply_start_pwm_floor(ControlTrackSystem_t *sys, float target, float actual, float out)
{
    uint32_t elapsed;

    if (!sys || !sys->isRunning) {
        return out;
    }

    elapsed = sys->tickCount - sys->runStartTick;
    if (elapsed >= TRACK_SPEED_START_KICK_MS) {
        return out;
    }

    if (target < TRACK_SPEED_START_TARGET_MIN) {
        return out;
    }

    if (track_absf(actual) > TRACK_SPEED_START_ACTUAL_MAX) {
        return out;
    }

    if (out < TRACK_SPEED_START_PWM_MIN) {
        return TRACK_SPEED_START_PWM_MIN;
    }

    return out;
}

static void track_control_step(ControlTrackSystem_t *sys)
{
    float baseTarget;
    float leftTargetPulse;
    float rightTargetPulse;
    float countDiffComp;
    uint8_t feedbackReady;
    int16_t leftPwm;
    int16_t rightPwm;

    Encoder_UpdateSpeed(&sys->encoder, TRACK_CONTROL_PERIOD_MS);
    track_poll_imu(sys);
    feedbackReady = track_update_feedback_speed(sys);

    if (feedbackReady) {
        sys->leftActualSpeed = sys->leftFeedbackSpeed;
        sys->rightActualSpeed = sys->rightFeedbackSpeed;
    }

    track_update_line_outer_loop(sys);
    if (!sys->isRunning) {
        return;
    }

    baseTarget = track_ramp_speed_target(sys);
    baseTarget = track_adjust_base_target(sys, baseTarget);
    track_mix_target_speeds(sys, baseTarget);

    leftTargetPulse = sys->leftTargetSpeed;
    rightTargetPulse = sys->rightTargetSpeed;

    if (feedbackReady) {
        sys->leftSpeedOut = track_speed_pid_step(
            leftTargetPulse,
            sys->leftActualSpeed,
            &sys->leftSpeedIntegral,
            &sys->leftSpeedPrevError,
            sys->speedKp,
            sys->speedKi,
            sys->speedKd,
            TRACK_SPEED_FF_GAIN,
            1u);
        sys->rightSpeedOut = track_speed_pid_step(
            rightTargetPulse,
            sys->rightActualSpeed,
            &sys->rightSpeedIntegral,
            &sys->rightSpeedPrevError,
            sys->speedKp,
            sys->speedKi,
            sys->speedKd,
            TRACK_SPEED_FF_GAIN,
            1u);
    }
    sys->leftSpeedOut = track_apply_start_pwm_floor(sys, sys->leftTargetSpeed, sys->leftActualSpeed, sys->leftSpeedOut);
    sys->rightSpeedOut = track_apply_start_pwm_floor(sys, sys->rightTargetSpeed, sys->rightActualSpeed, sys->rightSpeedOut);

#if TRACK_GUIDANCE_DISABLED
    countDiffComp = track_count_diff_pid_step(sys);
    sys->leftSpeedOut += countDiffComp;
    sys->rightSpeedOut -= countDiffComp;
#else
    if (track_startup_straight_active(sys)) {
        countDiffComp = track_count_diff_pid_step(sys);
        sys->leftSpeedOut += countDiffComp;
        sys->rightSpeedOut -= countDiffComp;
    } else {
        countDiffComp = 0.0f;
        sys->countDiffOut = 0.0f;
        sys->countDiffError = 0.0f;
        sys->countDiffIntegral = 0.0f;
        sys->countDiffPrevError = 0.0f;
    }
#endif

    sys->leftSpeedOut = track_clampf(sys->leftSpeedOut, 0.0f, TRACK_SPEED_OUT_LIMIT);
    sys->rightSpeedOut = track_clampf(sys->rightSpeedOut, 0.0f, TRACK_SPEED_OUT_LIMIT);
    sys->leftSpeedOut = track_apply_output_slew(sys->leftSpeedOut, (float)sys->leftPwm);
    sys->rightSpeedOut = track_apply_output_slew(sys->rightSpeedOut, (float)sys->rightPwm);

    sys->leftSpeedError = leftTargetPulse - sys->leftActualSpeed;
    sys->rightSpeedError = rightTargetPulse - sys->rightActualSpeed;
    sys->basePwm = (int16_t)((sys->leftSpeedOut + sys->rightSpeedOut) * 0.5f);

    leftPwm = track_clamp_i16((int16_t)sys->leftSpeedOut, TRACK_BASE_PWM_MIN, (int16_t)sys->pwmMax);
    rightPwm = track_clamp_i16((int16_t)sys->rightSpeedOut, TRACK_BASE_PWM_MIN, (int16_t)sys->pwmMax);

    Motor_Enable();
    track_apply_output(sys, leftPwm, rightPwm);
}

void ControlTrack_Init(ControlTrackSystem_t *sys)
{
    if (!sys) return;
    memset(sys, 0, sizeof(*sys));
    track_sensor_gpio_init();
    sys->targetSpeed = TRACK_TARGET_SPEED_DEFAULT;
    sys->speedKp = TRACK_SPEED_KP;
    sys->speedKi = TRACK_SPEED_KI;
    sys->speedKd = TRACK_SPEED_KD;
    sys->lineKp = TRACK_LINE_KP;
    sys->lineKi = TRACK_LINE_KI;
    sys->lineKd = TRACK_LINE_KD;
    sys->pwmMax = TRACK_PWM_MAX;
    track_stop_output(sys);
}

uint8_t ControlTrack_Start(ControlTrackSystem_t *sys)
{
    if (!sys) return 0u;
#if TRACK_GUIDANCE_DISABLED
    if (!track_sample_line(sys)) {
        sys->sensorBits = 0u;
        sys->sensorCount = 0u;
        sys->lineDetected = 0u;
        sys->linePosition = 0.0f;
        sys->linePositionRaw = 0.0f;
    }
#else
    if (!track_sample_line(sys)) return 0u;
#endif

    memset(&sys->encoder, 0, sizeof(sys->encoder));
    memset(&sys->icm, 0, sizeof(sys->icm));
    Encoder_Reset();
    if (ICM42688_ReadAll(&sys->icm)) {
        ICM42688_ResetAttitude(&sys->icm);
        sys->imuDataValid = 1u;
    }

    sys->isRunning = 1u;
    sys->runStartTick = sys->tickCount;
    sys->lastControlTick = sys->tickCount;
    sys->hbLastTick = sys->tickCount;
    sys->imuYawSampleTick = sys->tickCount;
    sys->expStreamLastTick = sys->tickCount;
    sys->lineMissingCount = 0u;
    sys->lineLostCount = 0u;
    track_reset_speed_loop(sys);
    track_reset_line_loop(sys);
    sys->linePositionRaw = sys->linePosition;
    sys->linePrevError = sys->linePosition;
    sys->lineError = sys->linePosition;
    sys->lastSeenError = sys->linePosition;
    sys->leftPwm = 0;
    sys->rightPwm = 0;
    Motor_Enable();
    return 1u;
}

void ControlTrack_Stop(ControlTrackSystem_t *sys)
{
    if (!sys) return;
    sys->isRunning = 0u;
    sys->lineMissingCount = 0u;
    sys->lineLostCount = 0u;
    sys->hbLastTick = 0u;
    sys->expStreamLastTick = 0u;
    track_reset_speed_loop(sys);
    track_reset_line_loop(sys);
    Encoder_Reset();
    track_stop_output(sys);
}

void ControlTrack_TimerTickISR(ControlTrackSystem_t *sys)
{
    if (!sys) return;
    sys->tickCount++;
}

void ControlTrack_Background(ControlTrackSystem_t *sys)
{
    char cmd[80];
    uint8_t got;
    uint8_t n = 0u;

    if (!sys) return;

    while (n < TRACK_CMD_MAX_PER_CALL) {
        got = VOFA_TakeCommand(cmd, sizeof(cmd));
        if (!got) break;
        track_parse_cmd(sys, cmd);
        n++;
    }

    track_handle_exp_timeout(sys);

    if (!sys->isRunning) {
        if (sys->expStreamEnabled && ((sys->tickCount - sys->hbLastTick) >= TRACK_VOFA_SEND_PERIOD_MS)) {
            sys->hbLastTick = sys->tickCount;
            track_send_hb(sys);
        }
        return;
    }

    while ((sys->tickCount - sys->lastControlTick) >= TRACK_CONTROL_PERIOD_MS) {
        sys->lastControlTick += TRACK_CONTROL_PERIOD_MS;
        track_control_step(sys);
        if (!sys->isRunning) {
            break;
        }
    }

    if ((sys->tickCount - sys->hbLastTick) >= TRACK_VOFA_SEND_PERIOD_MS) {
        sys->hbLastTick = sys->tickCount;
        track_send_hb(sys);
    }
}
